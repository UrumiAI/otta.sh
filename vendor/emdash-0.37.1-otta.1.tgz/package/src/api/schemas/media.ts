import { z } from "zod";

import { isValidFocalPointUpdate } from "#media/focal-point.js";

import { cursorPaginationQuery } from "./common.js";
import { mediaUsageSummarySchema } from "./media-usage.js";

// ---------------------------------------------------------------------------
// Media: Input schemas
// ---------------------------------------------------------------------------

/**
 * Accepts a comma-separated string (from URL query params) or an array of
 * strings (from JSON body or programmatic use) and normalises to string[].
 */
const mimeTypeFilter = z
	.union([z.string(), z.array(z.string())])
	.transform((v) => {
		const arr = Array.isArray(v) ? v : v.split(",");
		return arr.map((s) => s.trim()).filter((s) => s.length > 0);
	})
	.optional();

export const mediaListQuery = cursorPaginationQuery
	.extend({
		page: z.coerce.number().int().min(1).max(Number.MAX_SAFE_INTEGER).optional(),
		mimeType: mimeTypeFilter,
		folderId: z
			.union([z.literal("unfiled"), z.string().min(1).max(64)])
			.optional()
			.meta({
				description:
					"Filter by a media folder ID. Use `unfiled` for the Main library; omit for all media.",
			}),
		/** Case-insensitive filename substring search (also matches extensions). */
		q: z.string().trim().min(1).max(200).optional(),
		includeUsage: z.literal("1").optional().meta({
			description: "Include a coverage-aware usage summary on each media item",
		}),
	})
	.refine(({ cursor, page }) => cursor === undefined || page === undefined, {
		message: "cursor and page cannot be used together",
		path: ["page"],
	})
	.meta({ id: "MediaListQuery" });

export const mediaGetQuery = z
	.object({
		includeUsage: z.literal("1").optional().meta({
			description: "Include a coverage-aware usage summary on the media item",
		}),
	})
	.meta({ id: "MediaGetQuery" });

export const mediaUpdateBody = z
	.object({
		alt: z.string().optional(),
		caption: z.string().optional(),
		width: z.number().int().positive().optional(),
		height: z.number().int().positive().optional(),
		folderId: z
			.union([z.literal("unfiled"), z.string().min(1).max(64)])
			.nullable()
			.optional()
			.transform((value) => (value === "unfiled" ? null : value))
			.meta({
				description:
					"Assign a media folder ID, or use null or `unfiled` to return the item to the Main library.",
			}),
		focalX: z.number().min(0).max(1).nullable().optional(),
		focalY: z.number().min(0).max(1).nullable().optional(),
	})
	.superRefine((value, context) => {
		if (!isValidFocalPointUpdate(value)) {
			context.addIssue({
				code: "custom",
				message: "focalX and focalY must both be numbers or both be null",
				path: ["focalX"],
			});
		}
	})
	.meta({ id: "MediaUpdateBody" });

export const mediaFolderIdSchema = z.string().min(1).max(64);

export const mediaFolderListQuery = cursorPaginationQuery
	.extend({ q: z.string().trim().min(1).max(200).optional() })
	.meta({ id: "MediaFolderListQuery" });

const mediaFolderNameSchema = z.string().refine(
	(value) => {
		const length = value.trim().length;
		return length >= 1 && length <= 200;
	},
	{ message: "Folder name must be between 1 and 200 characters" },
);

export const mediaFolderBody = z
	.object({ name: mediaFolderNameSchema })
	.meta({ id: "MediaFolderBody" });

/** Default maximum allowed file upload size (50 MB). */
export const DEFAULT_MAX_UPLOAD_SIZE = 50 * 1024 * 1024;

export function formatFileSize(bytes: number): string {
	if (bytes < 1024) return `${bytes}B`;
	if (bytes < 1024 * 1024) return `${Math.floor(bytes / 1024)}KB`;
	return `${Math.floor(bytes / 1024 / 1024)}MB`;
}

// Matches a full MIME type (type/subtype) with an optional semicolon-delimited
// parameter section. Forbids CR/LF to prevent header injection.
export const CONTENT_TYPE_RE = /^[a-z0-9][a-z0-9!#$&^_+\-.]*\/[a-z0-9!#$&^_+\-.]+(\s*;[^\r\n]*)?$/i;

export function mediaUploadUrlBody(maxSize: number) {
	if (!Number.isFinite(maxSize) || maxSize <= 0) {
		throw new Error(`EmDash: maxUploadSize must be a positive finite number, got ${maxSize}`);
	}
	return z
		.object({
			filename: z.string().min(1, "filename is required"),
			contentType: z
				.string()
				.min(1, "contentType is required")
				.regex(CONTENT_TYPE_RE, "Invalid content type"),
			size: z
				.number()
				.int()
				.nonnegative()
				.max(maxSize, `File size must not exceed ${formatFileSize(maxSize)}`),
			contentHash: z.string().optional(),
			fieldId: z.string().optional(),
			deduplicate: z.boolean().optional(),
			ensureUniqueFilename: z.boolean().optional(),
			folderId: mediaFolderIdSchema.nullable().optional(),
		})
		.meta({ id: "MediaUploadUrlBody" });
}

export const mediaUploadDeduplicateForm = z
	.enum(["true", "false"])
	.default("true")
	.transform((value) => value === "true");

export const mediaUploadEnsureUniqueFilenameForm = z
	.enum(["true", "false"])
	.default("false")
	.transform((value) => value === "true");

export const mediaReplaceMetadataForm = z.object({
	width: z.coerce.number().int().positive().max(Number.MAX_SAFE_INTEGER),
	height: z.coerce.number().int().positive().max(Number.MAX_SAFE_INTEGER),
});

const binaryFileSchema = z.string().meta({ format: "binary" });

export const mediaDirectUploadBody = z
	.object({
		file: binaryFileSchema,
		width: z.string().optional(),
		height: z.string().optional(),
		thumbnail: binaryFileSchema.optional(),
		fieldId: z.string().optional(),
		deduplicate: z.enum(["true", "false"]).optional(),
		ensureUniqueFilename: z.enum(["true", "false"]).optional(),
		folderId: z.union([mediaFolderIdSchema, z.literal("unfiled")]).optional(),
	})
	.meta({ id: "MediaDirectUploadBody" });

export const mediaReplaceBody = z
	.object({
		file: binaryFileSchema,
		width: z.number().int().positive(),
		height: z.number().int().positive(),
	})
	.meta({ id: "MediaReplaceBody" });

export const mediaConfirmBody = z
	.object({
		size: z.number().int().nonnegative().optional(),
		width: z.number().int().positive().optional(),
		height: z.number().int().positive().optional(),
	})
	.meta({ id: "MediaConfirmBody" });

export const mediaProviderListQuery = cursorPaginationQuery
	.extend({
		query: z.string().optional(),
		mimeType: mimeTypeFilter,
	})
	.meta({ id: "MediaProviderListQuery" });

// ---------------------------------------------------------------------------
// Media: Response schemas
// ---------------------------------------------------------------------------

const mediaStatusSchema = z.enum(["pending", "ready", "failed"]);

export const mediaItemSchema = z
	.object({
		id: z.string(),
		filename: z.string(),
		mimeType: z.string(),
		size: z.number().nullable(),
		width: z.number().nullable(),
		height: z.number().nullable(),
		focalX: z.number().nullable(),
		focalY: z.number().nullable(),
		alt: z.string().nullable(),
		caption: z.string().nullable(),
		storageKey: z.string(),
		status: mediaStatusSchema,
		contentHash: z.string().nullable(),
		blurhash: z.string().nullable(),
		dominantColor: z.string().nullable(),
		createdAt: z.string(),
		authorId: z.string().nullable(),
		folderId: z.string().nullable(),
	})
	.meta({ id: "MediaItem" });

export const mediaFolderSchema = z
	.object({ id: z.string(), name: z.string() })
	.meta({ id: "MediaFolder" });

export const mediaFolderResponseSchema = z
	.object({ item: mediaFolderSchema })
	.meta({ id: "MediaFolderResponse" });

export const mediaFolderListResponseSchema = z
	.object({ items: z.array(mediaFolderSchema), nextCursor: z.string().optional() })
	.meta({ id: "MediaFolderListResponse" });

export const mediaResponseSchema = z
	.object({ item: mediaItemSchema })
	.meta({ id: "MediaResponse" });

export const mediaReadItemSchema = mediaItemSchema
	.extend({ usage: mediaUsageSummarySchema.optional() })
	.meta({ id: "MediaReadItem" });

export const mediaReadResponseSchema = z
	.object({ item: mediaReadItemSchema })
	.meta({ id: "MediaReadResponse" });

export const mediaListReadItemSchema = mediaReadItemSchema
	.extend({ url: z.string() })
	.meta({ id: "MediaListReadItem" });

export const mediaListReadResponseSchema = z
	.object({
		items: z.array(mediaListReadItemSchema),
		nextCursor: z.string().optional(),
		totalCount: z.number().int().nonnegative().optional(),
	})
	.meta({ id: "MediaListReadResponse" });

export const mediaListResponseSchema = z
	.object({
		items: z.array(mediaItemSchema),
		nextCursor: z.string().optional(),
		totalCount: z.number().int().nonnegative().optional(),
	})
	.meta({ id: "MediaListResponse" });

export const mediaUploadUrlResponseSchema = z
	.object({
		uploadUrl: z.string(),
		method: z.literal("PUT"),
		headers: z.record(z.string(), z.string()),
		mediaId: z.string(),
		storageKey: z.string(),
		expiresAt: z.string(),
	})
	.meta({ id: "MediaUploadUrlResponse" });

export const mediaExistingResponseSchema = z
	.object({
		existing: z.literal(true),
		mediaId: z.string(),
		storageKey: z.string(),
		url: z.string(),
	})
	.meta({ id: "MediaExistingResponse" });

export const mediaConfirmResponseSchema = z
	.object({
		item: mediaItemSchema.extend({ url: z.string() }),
	})
	.meta({ id: "MediaConfirmResponse" });

export const mediaUploadResponseSchema = z
	.object({
		item: mediaItemSchema.extend({ url: z.string() }),
		deduplicated: z.literal(true).optional(),
	})
	.meta({ id: "MediaUploadResponse" });

export const mediaReplaceResponseSchema = z
	.object({ item: mediaItemSchema.extend({ url: z.string() }) })
	.meta({ id: "MediaReplaceResponse" });

export const mediaStreamUploadResponseSchema = z
	.object({
		uploaded: z.literal(true),
		size: z.number().int().nonnegative(),
	})
	.meta({ id: "MediaStreamUploadResponse" });
